﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Addcotegory : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindDropDown();
            BindGridView();
        }

    }

    private void MessageBox(string msg)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + msg + "')", true);
    }

    private void BindGridView()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("select * from SubCategoriesTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                tblAddCrousel.DataSource = dt;
                tblAddCrousel.DataBind();
            }
            else
            {
                tblAddCrousel.DataSource = null;
                tblAddCrousel.DataBind();
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message);
        }
    }
    private void BindDropDown()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("SELECT Categories FROM CategoriesTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DropDownList1.DataSource = dt;
            DropDownList1.DataTextField = "Categories";
            DropDownList1.DataValueField = "Categories";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "select Categories");
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO SubCategoriesTable(Categories,SubCategories, Date) VALUES (@Categories, @SubCategories, @Date)", con);
            cmd.Parameters.AddWithValue("@Categories", DropDownList1.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@SubCategories", TextBox1.Text);
            cmd.Parameters.AddWithValue("@Date", DateTime.Now.ToString("dd-MM-yyyy"));

            con.Open();
            int res = cmd.ExecuteNonQuery();
            con.Close();

            if (res > 0)
            {
                MessageBox("Save Successful");
                BindGridView();
                TextBox1.Text = "";
            }
            else
            {
                MessageBox("Save Failed");
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message + "error");
        }
    }
}
