﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Addkids : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            show();
        }

    }
    private void messagebox(string sms)
    {
        if (!string.IsNullOrEmpty(sms))
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + sms + "')", true);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            if (FileUpload1.HasFile)
            {
                string str = FileUpload1.FileName.ToString();
                FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Admin/imageMens/" + str));
                SqlCommand cmd = new SqlCommand("Insert into AddKids(Image,Kids,Price)values(@Image,@Kids,@Price)", con);
                cmd.Parameters.AddWithValue("@Image", str);
                cmd.Parameters.AddWithValue("@Kids", TextBox1.Text);
                cmd.Parameters.AddWithValue("@Price", TextBox2.Text);

                con.Open();
                int res = cmd.ExecuteNonQuery();
                con.Close();

                messagebox("Data KidsWear Successful");

            }
        }
        catch (Exception ex)
        {
            messagebox("Data Failed");

        }

    }
    public void show()
    {
        SqlCommand cmd = new SqlCommand("SELECT * FROM AddKids", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
        }
    }
}