﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Addmens : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            show();
        }

    }
    private void messagebox(string sms)
    {
        if (!string.IsNullOrEmpty(sms))
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + sms + "')", true);
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            if (FileUpload1.HasFile)
            {
                string str = FileUpload1.FileName.ToString();
                FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Admin/imageMens/" + str));
                SqlCommand cmd= new SqlCommand("Insert into MensWear(MensWear,Price,Image)values(@MensWear,@Price,@Image)",con);
                cmd.Parameters.AddWithValue("@MensWear", TextBox1.Text);
                cmd.Parameters.AddWithValue("@Price", TextBox2.Text);
                cmd.Parameters.AddWithValue("@Image", str);

                con.Open();
               int res= cmd.ExecuteNonQuery();
                con.Close();
                   
               messagebox("Data MensWear Successful");

            }
        }
        catch(Exception ex)
        {
            messagebox("Data Failed");

        }

    }
    public void show()
    {
        SqlCommand cmd = new SqlCommand("SELECT * FROM MensWear", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
        }
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
            SqlCommand cmd = new SqlCommand("DELETE FROM MensWear  WHERE id = @id", con);
            cmd.Parameters.AddWithValue("@id", id);
            con.Open();
            int res = cmd.ExecuteNonQuery();
            con.Close();
            if (res > 0)
            {
                messagebox("deleted");
                show();
            }
            else
            {
                messagebox("delete fail");
            }
        }
        catch (Exception ex)
        {
            messagebox(ex.Message);
        }
    }
}