﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_view : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    //protected void tblViewContact(object sender, GridViewCommandEventArgs e)
    //{
    //    if (e.CommandName == "View")
    //    {
    //        int rowIndex = Convert.ToInt32(e.CommandArgument);
    //        // Access the data from the row using the rowIndex
    //        tblViewContact row = tblViewContact.Rows[rowIndex];
    //        // Assuming you have a Label control in the GridView to display data, you can access it like this:
    //        Label Label1 = (Label)row.FindControl("Id");
    //        string data = Label1.Text; // Accessing the text from the Label control

    //        // Now you can perform any actions with the data obtained from the row
    //        // For example, display it in a message box:
    //        messageBox("Data from selected row: " + data);
    //    }
    //}


}