﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_ContactDetails : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        BindContact();
    }

    private void messageBox(string sms)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + sms + "')", true);
    }

    private void BindContact()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("select * from Contacttable", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                tblViewContact.DataSource = dt;
                tblViewContact.DataBind();
            }
            else
            {
                tblViewContact.DataSource = null;
                tblViewContact.DataBind();
            }
        }
        catch (Exception ex)
        {
            messageBox(ex.Message);
        }
    }
}