﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Activities.Statements;

public partial class Admin_Addcotegory : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        BindCategories();
    }

    private void MessageBox(string msg)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + msg + "')", true);
    }

    private void BindCategories()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("select * from CategoriesTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                tblAddCrousel.DataSource = dt;
                tblAddCrousel.DataBind();
            }
            else
            {
                tblAddCrousel.DataSource = null;
                tblAddCrousel.DataBind();
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO CategoriesTable(Categories, Date) VALUES (@Categories, @Date)", con);
            cmd.Parameters.AddWithValue("@Categories", TextBox1.Text);
            cmd.Parameters.AddWithValue("@Date", DateTime.Now.ToString("dd-MM-yyyy"));

            con.Open();
            int res = cmd.ExecuteNonQuery();
            con.Close();

            if (res > 0)
            {
                MessageBox("Save Successful");
                BindCategories();
                TextBox1.Text = "";
            }
            else
            {
                MessageBox("Save Failed");
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message + "error");
        }
    }

    protected void btnPrintBill_Click(object sender, EventArgs e)
    {

    }
}