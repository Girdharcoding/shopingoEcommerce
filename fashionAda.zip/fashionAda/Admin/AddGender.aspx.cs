﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddGender : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindBrandRepeater();
        }
    }

    private void BindBrandRepeater()
    {
        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbms"].ConnectionString))
        {
            using (SqlCommand cmd = new SqlCommand("select * from tblGender", con))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    rptrBrands.DataSource = dt;
                    rptrBrands.DataBind();
                }
            }
        }
    }
    protected void btnAddGender_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(ddlGender.Text))
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbms"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO tblGender(GenderName) VALUES (@GenderName)", con);
                cmd.Parameters.AddWithValue("@GenderName", ddlGender.Text);
                cmd.ExecuteNonQuery();

                Response.Write("<script>alert('Brand Added Successfully');</script>");
                ddlGender.Text = string.Empty;
                con.Close();

                BindBrandRepeater(); // Refresh brand list
            }
        }

    }

    //protected void btnUpdategender_Click(object sender, EventArgs e)
    //{
    //    ddlGender.Text = "0";
    //    ddlGender.Visible = false;
    //    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbms"].ConnectionString);
    //    if (con.State == ConnectionState.Closed) { con.Open(); }
    //    SqlCommand cmd = new SqlCommand("insert into tblGender (BrandID,Name) values(@ID,@Name)", con);
    //    cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(txtID.Text));
    //    cmd.Parameters.AddWithValue("@Name", txtUpdateGender.Text);
    //    cmd.ExecuteNonQuery();
    //    Response.Write("<script>alert('Update successfully')</script>");
    //    txtID.Text = string.Empty;
    //    txtUpdateGender.Text = string.Empty;
    //    ddlGender.Text = string.Empty;
    //    ddlGender.Visible = true;
    //    ddlGender.Focus();

    //}

    //protected void txtID_TextChanged(object sender, EventArgs e)
    //{
    //    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbms"].ConnectionString);
    //    if (con.State == ConnectionState.Closed) { con.Open(); }
    //    SqlCommand cmd = new SqlCommand("select Name from tblGender where BrandID=@ID", con);
    //    cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(txtID.Text));
    //    SqlDataAdapter da = new SqlDataAdapter(cmd);
    //    DataSet ds = new DataSet();
    //    DataTable dt = new DataTable();
    //    da.Fill(ds, "dt");
    //    con.Close();
    //    if (ds.Tables[0].Rows.Count > 0)
    //    {
    //        txtUpdateGender.Enabled = true;
    //        txtUpdateGender.Text = ds.Tables[0].Rows[0]["Name"].ToString();

    //    }
    //    else
    //    {
    //        txtUpdateGender.Enabled = false;
    //        txtUpdateGender.Text = string.Empty;
    //    }
    //    con.Close();

    //}
}