﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddCarousel : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            show();
        }


    }
    private void messagebox(string sms)
    {
        if (!string.IsNullOrEmpty(sms))
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + sms + "')", true);
        }
    }
    public void show()
    {
        SqlCommand cmd = new SqlCommand("SELECT * FROM TableCarousel", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            if (FileUpload1.HasFile)
            {
                string str = FileUpload1.FileName.ToString();
                FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Admin/CarouselImage/" + str));
                SqlCommand cmd = new SqlCommand("Insert into TableCarousel(Image,Date)values(@Image,@Date)", con);
                cmd.Parameters.AddWithValue("@Image", str);
                cmd.Parameters.AddWithValue("@Date", DateTime.Now.ToString("dd,mm,yyyy"));

                con.Open();
                int res = cmd.ExecuteNonQuery();
                con.Close();

                messagebox("Image uploded");


            }
        }
        catch (Exception ex)
        {
            messagebox("Data Failed" + ex.Message);

        }

    }

    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        show();


    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        show();

    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
            SqlCommand cmd = new SqlCommand("DELETE FROM TableCarousel  WHERE id = @id", con);
            cmd.Parameters.AddWithValue("@id", id);
            con.Open();
            int res = cmd.ExecuteNonQuery();
            con.Close();
            if (res > 0)
            {
                messagebox("deleted");
                show();
            }
            else
            {
                messagebox("delete fail");
            }
        }
        catch (Exception ex)
        {
            messagebox(ex.Message);
        }

    }

    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

    }
}