﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Activities.Statements;

public partial class Admin_Products : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindDropDown();
            BindGridView();
        }
    }

    private void MessageBox(string msg)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + msg + "')", true);
    }

    private void BindGridView()
    {
        try
        {

            SqlCommand cmd = new SqlCommand("select * from ProductTable", con);
            cmd.Parameters.AddWithValue("@Id", 2);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                tblAddCrousel.DataSource = dt;
                tblAddCrousel.DataBind();
            }
            else
            {
                tblAddCrousel.DataSource = null;
                tblAddCrousel.DataBind();
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message);
        }
    }
    private void BindDropDown()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM CategoriesTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DropDownList1.DataSource = dt;
            DropDownList1.DataTextField = "Categories";
            DropDownList1.DataValueField = "Id";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "select Categories");
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message);
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("SELECT * FROM SubCategoriesTable WHERE Categories=@Categories", con);
        cmd.Parameters.AddWithValue("@Categories", DropDownList1.SelectedItem.ToString());
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        DropDownList2.DataSource = dt;
        DropDownList2.DataTextField = "SubCategories";
        DropDownList2.DataValueField = "Id";
        DropDownList2.DataBind();
        DropDownList2.Items.Insert(0, "select sub category");
    }

    string CImage = " ";
    public void Uploadimage1()
    {
        string filename = "";
        if (FileUpload1.HasFile)
        {
            filename = SaveFile1(FileUpload1.PostedFile);
        }
        else
        {
            filename = "n/a";
            MessageBox("Please select file");
        }
        if (filename != "n/a")
        {
            CImage = filename;
        }
    }
    public string SaveFile1(HttpPostedFile file)
    {
        string fileName = "";
        String savePath = Server.MapPath("~/UploadImage/");
        fileName = FileUpload1.FileName;
        byte[] fileSize = FileUpload1.FileBytes;
        string fileType = FileUpload1.PostedFile.ContentType;
        string pathToCheck = savePath + fileName;
        string tempfileName = "";
        try
        {
            if (System.IO.File.Exists(pathToCheck))
            {
                int counter = 2;
                while (System.IO.File.Exists(pathToCheck))
                {
                    tempfileName = counter.ToString() + fileName;
                    pathToCheck = savePath + tempfileName;
                    counter++;
                }
                fileName = tempfileName;
            }
            else
            {
            }
            savePath += fileName;
            FileUpload1.SaveAs(savePath);
        }
        catch (Exception e)
        {
            string errmsg = e.Message;
        }
        return fileName;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            Uploadimage1();
            SqlCommand cmd = new SqlCommand("INSERT INTO ProductTable(CategoryId,SubCategoryId,ProductName,Price,Description,Size,Quantity,OfferPrice,ImageName,Date) VALUES (@CategoryId, @SubCategoryId,@ProductName, @Price, @Description, @Size, @Quantity, @OfferPrice, @ImageName, @Date)", con);
            cmd.Parameters.AddWithValue("@CategoryId", DropDownList1.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@SubCategoryId", DropDownList2.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@ProductName", txtProductName.Text);
            cmd.Parameters.AddWithValue("@Price", txtPrice.Text);
            cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
            cmd.Parameters.AddWithValue("@Size", txtSize.Text);
            cmd.Parameters.AddWithValue("@Quantity", txtQuantity.Text);
            cmd.Parameters.AddWithValue("@OfferPrice", txtOfferPrice.Text);
            cmd.Parameters.AddWithValue("@ImageName", CImage);
            cmd.Parameters.AddWithValue("@Date", DateTime.Now.ToString("dd-MM-yyyy"));
            con.Open();
            int res = cmd.ExecuteNonQuery();
            con.Close();

            if (res > 0)
            {
                MessageBox("Save Successful");
                BindGridView();
                txtProductName.Text = "";
                txtPrice.Text = "";
                txtDescription.Text = "";
                txtSize.Text = "";
                txtQuantity.Text = "";
                txtOfferPrice.Text = "";
            }
            else
            {
                MessageBox("Save Failed");
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message + "error");
        }
    }

    protected void tblAddCrousel_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int id = Convert.ToInt32(tblAddCrousel.DataKeys[e.RowIndex].Value);

            using (SqlCommand cmd = new SqlCommand("DELETE FROM ProductTable WHERE Id = @Id", con))
            {
                cmd.Parameters.AddWithValue("@Id", id);

                con.Open();
                int res = cmd.ExecuteNonQuery();

                if (res > 0)
                {
                    MessageBox("Deleted");
                    BindGridView();
                }
                else
                {
                    MessageBox("Delete failed");
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message);
        }
    }

}