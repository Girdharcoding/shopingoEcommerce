﻿internal class CartItem
{
}