﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class project_Login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=newproject;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    private void messagebox(string sms)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "showalart", "alert('" + sms + "')", true);
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        string username = TextUsername.Text;
        string password = TextPassword.Text;

        SqlCommand cmd = new SqlCommand("SELECT * FROM Tablesignup WHERE Username = @Username AND Password = @Password", con);
        cmd.Parameters.AddWithValue("@Username", username);
        cmd.Parameters.AddWithValue("@Password", password);

        con.Open();
        SqlDataReader reader = cmd.ExecuteReader();

        if (reader.Read())
        {
            string imagePath = reader["Image"].ToString();
            Session["Image"] = imagePath;
            Session["Username"] = username;
            con.Close();
            messagebox("Login Successful");
            Response.Redirect("/Admin/Default.aspx");
        }
        else
        {
            con.Close();
            messagebox("Invalid username or password");
        }


    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Sinup.aspx");
    }
}

//using System;
//using System.Data;
//using System.Data.SqlClient;
//using System.Web.UI;

//public partial class project_Login : System.Web.UI.Page
//{
//    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=newproject;Integrated Security=True");

//    protected void Page_Load(object sender, EventArgs e)
//    {
//    }

//    private void MessageBox(string sms)
//    {
//        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + sms + "')", true);
//    }

//    protected void Button1_Click(object sender, EventArgs e)
//    {
//        string username = TextUsername.Text;
//        string password = TextPassword.Text;

//        try
//        {
//            con.Open();
//            SqlCommand cmd = new SqlCommand("SELECT * FROM Tablesignup WHERE Username = @Username AND Password = @Password", con);
//            cmd.Parameters.AddWithValue("@Username", username);
//            cmd.Parameters.AddWithValue("@Password", password);

//            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
//            {
//                DataTable dt = new DataTable();
//                da.Fill(dt);

//                if (dt.Rows.Count > 0)
//                {
//                    MessageBox("Login Successful");
//                    Response.Redirect("/Admin/Default.aspx");
//                }
//                else
//                {
//                    MessageBox("Invalid username or password");
//                }
//            }
//        }
//        catch (Exception ex)
//        {
//            MessageBox("An error occurred: " + ex.Message);
//        }
//        finally
//        {
//            con.Close();
//        }
//    }

//    protected void Button2_Click(object sender, EventArgs e)
//    {
//        Response.Redirect("Sinup.aspx");
//    }
//}
