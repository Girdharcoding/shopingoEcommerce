﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class NewFolder1_MensWear : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");

    String id, pid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //id = Request.QueryString["Id"].ToString();
            BindRepeater1();
            BindRepeater2();

        }
    }

    private void MessageBox(string msg)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + msg + "')", true);
    }

    private void BindRepeater1()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM ProductTable WHERE SubCategoryId=@SubCategoryId", con);
            cmd.Parameters.AddWithValue("@SubCategoryId", id);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                Repeater1.DataSource = dt;
                Repeater1.DataBind();
            }
            else
            {
                Repeater1.DataSource = null;
                Repeater1.DataBind();
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message);
        }
        finally
        {
            con.Close();
        }
    }

    private void BindRepeater2()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM ProductTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                Repeater2.DataSource = dt;
                Repeater2.DataBind();
            }
            else
            {
                Repeater2.DataSource = null;
                Repeater2.DataBind();
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message);
        }
        finally
        {
            con.Close();
        }
    }



    protected void btnAddToCart_Click(object sender, EventArgs e)
    {
    }

    String productName, price, imgname, desc;
    int qty;
    public void getProductDetail()
    {
        SqlCommand cmd = new SqlCommand("select * from ProductTable where Id=@Id", con);
        cmd.Parameters.AddWithValue("Id", pid);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            productName = dt.Rows[0]["ProductName"].ToString();
            desc = dt.Rows[0]["Description"].ToString();
            price = dt.Rows[0]["OfferPrice"].ToString();
            qty = 1;
            imgname = dt.Rows[0]["ImageName"].ToString();
        }
    }
    protected void Repeater2_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "AddToCart")
        {
            pid = e.CommandArgument.ToString();
            getProductDetail();
            double qty1 = Convert.ToDouble(qty);
            double price1 = Convert.ToDouble(price);
            double totalPrice1 = qty1 * price1;
            if (Context.Session["cartitem"] == null)
            {
                // If cart is empty, create a new DataTable and add the product to it
                DataTable dt = new DataTable();
                dt.Columns.AddRange(new DataColumn[7] {
                new DataColumn("Id"),
                new DataColumn("ImageName"),
                new DataColumn("ProductName"),
                new DataColumn("Description"),
                new DataColumn("Quantity"),
                new DataColumn("OfferPrice"),
                new DataColumn("TotalPrice")
            });
                dt.Rows.Add(pid, imgname, productName, desc, qty, price, totalPrice1);
                Context.Session["cartitem"] = dt;
            }
            else
            {
                DataTable dt = (DataTable)Context.Session["cartitem"];

                // Check if the item already exists in the cart
                bool itemExists = false;
                foreach (DataRow row in dt.Rows)
                {
                    if (row["ProductName"].ToString() == productName && row["Description"].ToString() == desc && row["OfferPrice"].ToString() == price)
                    {
                        // Item already exists, you can update quantity or perform any other action here
                        itemExists = true;
                        break;
                    }
                }

                if (!itemExists)
                {
                    DataRow newRow = dt.NewRow();
                    newRow["Id"] = pid;
                    newRow["ImageName"] = imgname;
                    newRow["ProductName"] = productName;
                    newRow["Description"] = desc;
                    newRow["Quantity"] = qty;
                    newRow["OfferPrice"] = price;
                    newRow["TotalPrice"] = totalPrice1;
                    dt.Rows.Add(newRow);
                    Context.Session["cartitem"] = dt;
                }
            }
        }
    }

    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "AddToCart")
        {
            pid = e.CommandArgument.ToString();
            //Label lblProduct = e.Item.FindControl("lblProductName") as Label;
            //string product = lblProduct.Text;
            getProductDetail();
            double qty1 = Convert.ToDouble(qty);
            double price1 = Convert.ToDouble(price);
            double totalPrice1 = qty1 * price1;
            if (Context.Session["cartitem"] == null)
            {
                // If cart is empty, create a new DataTable and add the product to it
                DataTable dt = new DataTable();
                dt.Columns.AddRange(new DataColumn[7] {
                new DataColumn("Id"),
                new DataColumn("ImageName"),
                new DataColumn("ProductName"),
                new DataColumn("Description"),
                new DataColumn("Quantity"),
                new DataColumn("OfferPrice"),
                new DataColumn("TotalPrice")
            });
                dt.Rows.Add(pid, imgname, productName, desc, qty, price, totalPrice1);
                Context.Session["cartitem"] = dt;
            }
            else
            {
                DataTable dt = (DataTable)Context.Session["cartitem"];

                // Check if the item already exists in the cart
                bool itemExists = false;
                foreach (DataRow row in dt.Rows)
                {
                    if (row["ProductName"].ToString() == productName && row["Description"].ToString() == desc && row["OfferPrice"].ToString() == price)
                    {
                        // Item already exists, you can update quantity or perform any other action here
                        itemExists = true;
                        break;
                    }
                }

                if (!itemExists)
                {
                    DataRow newRow = dt.NewRow();
                    newRow["Id"] = pid;
                    newRow["ImageName"] = imgname;
                    newRow["ProductName"] = productName;
                    newRow["Description"] = desc;
                    newRow["Quantity"] = qty;
                    newRow["OfferPrice"] = price;
                    newRow["TotalPrice"] = totalPrice1;
                    dt.Rows.Add(newRow);
                    Context.Session["cartitem"] = dt;

                }
            }
        }
    }
}
