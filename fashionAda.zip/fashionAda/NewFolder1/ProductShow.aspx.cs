﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewFolder1_ProductShow : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            show();
        }
    }
    private void MessageBox(String msg)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + msg + "');", true);
    }

    public void show()
    {
        try
        {
            // Open the connection
            con.Open();

            // Pass the connection object to the SqlCommand constructor
            SqlCommand cmd = new SqlCommand("SELECT * FROM Addproduct WHERE CatName = @searchText OR SubCatName = @searchText OR BrandName = @searchText", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                Repeater1.DataSource = dt;
                Repeater1.DataBind();
            }
            else
            {
                Repeater1.DataSource = null;
                Repeater1.DataBind();
                MessageBox("Data NO found");

            }
        }
        catch (Exception )
        {
            // Handle the exception, for example, log or display an error message
        }
        finally
        {
            // Close the connection
            con.Close();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            // Open the connection
            con.Open();

            // Create a SqlCommand object with the query and connection
            SqlCommand cmd = new SqlCommand("SELECT * FROM Addproduct WHERE CatName = @searchText OR SubCatName = @searchText OR BrandName = @searchText", con);
            // Add parameters to the command to avoid SQL injection
            cmd.Parameters.AddWithValue("@searchText", TextBox1.Text); // Assuming TextBox1 is the TextBox where the user enters the search text
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                Repeater1.DataSource = dt;
                Repeater1.DataBind();
            }
            else
            {
                Repeater1.DataSource = null;
                Repeater1.DataBind();
                MessageBox("Data NO found");
            }
        }
        catch (Exception )
        {
            // Handle exceptions here
        }
        finally
        {
            // Close the connection
            con.Close();
        }
    }
}
