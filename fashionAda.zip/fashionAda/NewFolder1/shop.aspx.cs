﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Security.Cryptography;
using System.Web;
using System.Web.DynamicData;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class NewFolder1_shop : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindCategories();
        }
    }

    private void MessageBox(string msg)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + msg + "')", true);
    }

    private void BindCategories()
    {
        try
        {
            using (SqlCommand cmd = new SqlCommand("SELECT * FROM ProductTable", con))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    Repeater1.DataSource = dt;
                    Repeater1.DataBind();
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message);
        }
    }

    private void getProductDetail(string Id, out string imgname, out string productName, out string desc, out int qty, out string price)
    {
        imgname = productName = desc = price = "";
        qty = 0;

        using (SqlConnection connection = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True"))
        {
            SqlCommand command = new SqlCommand("SELECT * FROM ProductTable WHERE Id = @Id", connection);
            command.Parameters.AddWithValue("@Id", Id);

            try
            {
                connection.Open();
                using (SqlDataAdapter da = new SqlDataAdapter(command))
                {
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        productName = dt.Rows[0]["ProductName"].ToString();
                        desc = dt.Rows[0]["Description"].ToString();
                        price = dt.Rows[0]["OfferPrice"].ToString();
                        qty = 1;
                        imgname = dt.Rows[0]["ImageName"].ToString();
                        // Assign other fields accordingly
                    }
                }
            }
            catch (Exception )
            {
                // Handle the exception
            }
        }
    }

    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "AddToCart")
        {
            string pid = e.CommandArgument.ToString();
            string productName, price, imgname, desc;
            int qty;

            getProductDetail(pid, out imgname, out productName, out desc, out qty, out price);

            double qty1, price1, totalPrice1;
            if (double.TryParse(price, out price1) && int.TryParse(qty.ToString(), out qty))
            {
                qty1 = Convert.ToDouble(qty);
                totalPrice1 = qty1 * price1;

                DataTable dt;
                if (Context.Session["cartitem"] == null)
                {
                    dt = new DataTable();
                    dt.Columns.AddRange(new DataColumn[7] {
                        new DataColumn("Id"),
                        new DataColumn("ImageName"),
                        new DataColumn("ProductName"),
                        new DataColumn("Description"),
                        new DataColumn("Quantity"),
                        new DataColumn("OfferPrice"),
                        new DataColumn("TotalPrice")
                    });
                    Context.Session["cartitem"] = dt;
                }
                else
                {
                    dt = (DataTable)Context.Session["cartitem"];
                }

                bool itemExists = false;
                foreach (DataRow row in dt.Rows)
                {
                    if (row["ProductName"].ToString() == productName && row["Description"].ToString() == desc && row["OfferPrice"].ToString() == price)
                    {
                        itemExists = true;
                        break;
                    }
                }

                if (!itemExists)
                {
                    DataRow newRow = dt.NewRow();
                    newRow["Id"] = pid;
                    newRow["ImageName"] = imgname;
                    newRow["ProductName"] = productName;
                    newRow["Description"] = desc;
                    newRow["Quantity"] = qty;
                    newRow["OfferPrice"] = price;
                    newRow["TotalPrice"] = totalPrice1;
                    dt.Rows.Add(newRow);
                    Context.Session["cartitem"] = dt;
                }
            }
            else
            {
                MessageBox("Invalid quantity or price.");
            }
        }
    }
}
