﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ForgetPassword : System.Web.UI.Page
{
    // Database connection string
    private readonly string connectionString = "Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True";

    protected void Page_Load(object sender, EventArgs e)
    {
        // Your code here
    }

    // Display alert message using JavaScript
    private void ShowAlert(string message)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + message + "')", true);
    }

    // Validate user input
    private bool ValidateInput()
    {
        if (string.IsNullOrEmpty(TextBox2.Text) || string.IsNullOrEmpty(TextBox3.Text))
        {
            ShowAlert("Username and Mobile No. are required.");
            return false;
        }
        return true;
    }

    protected void btnOpenModal_Click(object sender, EventArgs e)
    {
        // Clear any previous data in the modal
        TextBox1.Text = TextBox2.Text = TextBox3.Text = TextBox4.Text = TextBox5.Text = "";

        // Show the modal
        ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "$('#myModal').modal('show');", true);
    }

    protected void btnForgot_Click(object sender, EventArgs e)
    {
        if (ValidateInput())
        {
            string otp = Session["OTP"] as string;
            if (otp == TextBox4.Text)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand("UPDATE tblSignup SET Password=@Password WHERE Username=@Username and MobileNo=@MobileNo ", con);
                        cmd.Parameters.AddWithValue("@Password", TextBox5.Text);
                        cmd.Parameters.AddWithValue("@Username", TextBox2.Text);
                        cmd.Parameters.AddWithValue("@MobileNo", TextBox3.Text);
                        con.Open();
                        int res = cmd.ExecuteNonQuery();
                        if (res > 0)
                        {
                            ShowAlert("Changed Password successfully.");
                            TextBox1.Text = TextBox2.Text = TextBox3.Text = TextBox4.Text = TextBox5.Text = "";
                        }
                        else
                        {
                            ShowAlert("Failed to change password.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ShowAlert("An error occurred: " + ex.Message);
                }
            }
            else
            {
                ShowAlert("Enter valid OTP.");
            }
        }
    }

    protected void btnGenerateOTP_Click(object sender, EventArgs e)
    {
        if (ValidateInput())
        {
            try
            {
                // Your OTP generation and sending code here
                // After sending OTP, show the OTP input field
                TextBox4.Visible = true;
                TextBox5.Visible = true;
                btnForgot.Visible = true;
                btnGenerateOTP.Visible = false;

                // Generate a random 4-digit OTP
                Random random = new Random();
                int otp = random.Next(1000, 9999);

                // Store the OTP in a session variable for verification
                Session["OTP"] = otp;

                // Your code to send OTP to the user, either by email or SMS
                // For now, I'll just set the OTP to the TextBox for demonstration
                TextBox4.Text = otp.ToString();

                // Show the modal
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "$('#myModal').modal('show');", true);
            }
            catch (Exception ex)
            {
                ShowAlert("An error occurred: " + ex.Message);
            }
        }
    }
}
