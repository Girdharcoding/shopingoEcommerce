﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class project_Sinup : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=newproject;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    private void messageBox(string sms)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + sms + "')", true);
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");

    }

    protected void Btnsinup_Click1(object sender, EventArgs e)
    {
        try
        {
           
            if (FileUpload1.HasFile)    
            {
                string str = FileUpload1.FileName.ToString();   
                FileUpload1.PostedFile.SaveAs(Server.MapPath("~/profileimage/" + str));
                SqlCommand cmd = new SqlCommand("INSERT INTO Tablesignup(Name,Email,Mobile,Username,Password,Image)VALUES(@Name,@Email,@Mobile,@Username,@Password,@Image)", con);
                cmd.Parameters.AddWithValue("@Name", Textname.Text);
                cmd.Parameters.AddWithValue("@Email",TextEmail.Text);
                cmd.Parameters.AddWithValue("@Mobile", TextMobile.Text);
                cmd.Parameters.AddWithValue("@Username", TextUsername.Text);
                cmd.Parameters.AddWithValue("@Password", TextPassword.Text);
                cmd.Parameters.AddWithValue("@Image",str);


                con.Open();
                int res = cmd.ExecuteNonQuery();
                con.Close();

                messageBox("SignUp Successful");

               
            }
        }
        catch (Exception )
        {
            messageBox("SignUp failed");

        }
    }
}