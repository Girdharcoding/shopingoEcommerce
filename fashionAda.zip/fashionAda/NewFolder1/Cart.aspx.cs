﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Services;
using System.Web.UI;
public partial class NewFolder1_Cart : System.Web.UI.Page
{

    int productId;
    protected void Page_Load(object sender, EventArgs e)
    {
        ClientScript.RegisterStartupScript(this.GetType(), "confirmRemove", "function confirmRemove() { return confirm('Are you sure you want to remove this item from the cart?'); }", true);
        BindRepeater();
        BindCartData();
    }

    private void MessageBox(string msg)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + msg + "')", true);
    }



    private void BindCartData()
    {
        DataTable cartItems = (DataTable)Session["cartitem"];
        if (cartItems != null && cartItems.Rows.Count > 0)
        {
            Repeater1.DataSource = cartItems;
            Repeater1.DataBind();

            double subtotal = CalculateSubtotal(cartItems);
            lblSubtotal.Text = subtotal.ToString(); // Display subtotal

            double discount = CalculateDiscount(subtotal); // Calculate discount based on subtotal
            lbldiscount.Text = discount.ToString(); // Display discount

            // Calculate total (add shipping, taxes, etc., if applicable)
            double total = subtotal - discount; // Subtract discount from subtotal to get total
            lblTotal.Text = total.ToString(); // Display total
        }
        else
        {
            // Handle empty cart
            // You might want to display a message or redirect to a different page
            lblSubtotal.Text = "0.00"; // Display 0 as subtotal when cart is empty
            lbldiscount.Text = "0.00"; // Display 0 as discount when cart is empty
            lblTotal.Text = "0.00"; // Display 0 as total when cart is empty
        }
    }

    private double CalculateDiscount(double subtotal)
    {
        if (subtotal > 100)
        {
            return subtotal * 0.1; // 10% discount
        }
        else
        {
            return 0; // No discount
        }

    }

    private double CalculateSubtotal(DataTable cartItems)
    {
        double subtotal = 0;
        foreach (DataRow row in cartItems.Rows)
        {
            subtotal += Convert.ToDouble(row["TotalPrice"]);
        }
        return subtotal;
    }


    double subTotal = 0;
    private void BindRepeater()
    {
        if (Session["cartitem"] != null)
        {
            DataTable dt = (DataTable)Session["cartitem"];
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    subTotal += double.Parse(dr["TotalPrice"].ToString());


                }

                Repeater1.DataSource = dt;
                Repeater1.DataBind();
            }
            else
            {

            }

        }
    }

    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "RemoveFromCart")
        {
            // Get the index of the item to remove
            int rowIndex = e.Item.ItemIndex;

            // Retrieve the DataTable from the session
            DataTable dt = (DataTable)Session["cartitem"];

            // Remove the DataRow at the specified index
            dt.Rows.RemoveAt(rowIndex);

            // Update the session with the modified DataTable
            Session["cartitem"] = dt;

            // Rebind the Repeater to reflect the changes
            BindRepeater();
        }
    }

    //protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    //{
    //    if (e.CommandName == "RemoveFromCart")
    //    {
    //        // Get the index of the item to remove
    //        int rowIndex = e.Item.ItemIndex;

    //        // Retrieve the DataTable from the session
    //        DataTable dt = (DataTable)Session["cartitem"];

    //        // Remove the DataRow at the specified index
    //        dt.Rows.RemoveAt(rowIndex);

    //        // Update the session with the modified DataTable
    //        Session["cartitem"] = dt;

    //        // Rebind the Repeater to reflect the changes
    //        BindRepeater();
    //    }
    //}

    [WebMethod]
    public static int GetAvailableQuantity(int productId)
    {
        Console.WriteLine(productId + " hiii");
        int availableQuantity = 0;
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["dbms"].ConnectionString;

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "SELECT Quantity FROM ProductTable WHERE Id = @Id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Id", productId);

            try
            {
                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    availableQuantity = Convert.ToInt32(result);
                }
            }
            catch (Exception )
            {
                

            }
        }
        return availableQuantity;
    }

    protected void ProceedToCheckoutButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("Singin.aspx");

    }



    protected void ContinueShoppingButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("shop.aspx");
    }
}