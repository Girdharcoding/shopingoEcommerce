﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewFolder1_Sinups : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    private void messageBox(string sms)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + sms + "')", true);
    }

    protected void BtnSignup_Click(object sender, EventArgs e)
    {
        try
        {
            using (SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True"))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO Signuptable(Name,Email,Gender,Mobile,Locality,City,State,Pincode,UserName,Password,Full_Address,Date)VALUES(@Name,@Email,@Gender,@Mobile,@Locality,@City,@State,@Pincode,@UserName,@Password,@Full_Address,@Date)", con))
                {
                    cmd.Parameters.AddWithValue("@Name", txtName.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@Gender", ddlGender.Text);
                    cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                    cmd.Parameters.AddWithValue("@Locality", txtLocality.Text);
                    cmd.Parameters.AddWithValue("@City", txtCity.Text);
                    cmd.Parameters.AddWithValue("@State", txtState.Text);
                    cmd.Parameters.AddWithValue("@Pincode", txtPincode.Text);
                    cmd.Parameters.AddWithValue("@UserName", txtUserName.Text);
                    cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
                    cmd.Parameters.AddWithValue("@Full_Address", txtFullAddress.Text);
                    cmd.Parameters.AddWithValue("@Date", DateTime.Now.ToString("dd,MM,yyyy"));

                    con.Open();
                    int res = cmd.ExecuteNonQuery();
                    if (res > 0)
                    {
                        messageBox("SignUp Successful");
                    }
                    else
                    {
                        messageBox("SignUp failed");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            messageBox("SignUp failed: " + ex.Message);
        }
    }

}