﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using iTextSharp.text; // Add reference to iTextSharp library
using iTextSharp.text.pdf;
using System.Configuration;


public partial class NewFolder1_Checkout : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindCartData();

        }
    }



    private void MessageBox(string msg)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + msg + "')", true);
    }

    private void BindCartData()
        {
            DataTable cartItems = (DataTable)Session["cartitem"];
            if (cartItems != null && cartItems.Rows.Count > 0)
            {
            //Repeater1.DataSource = cartItems;
            //Repeater1.DataBind();
           

              double subtotal = CalculateSubtotal(cartItems);
                lblSubtotal.Text = subtotal.ToString(); // Display subtotal

               int quantity = CalculateQuantity(cartItems);
                lblQuantity.Text = quantity.ToString(); // Display total quantity of items


            double discount = CalculateDiscount(subtotal); // Calculate discount based on subtotal
                lbldiscount.Text = discount.ToString(); // Display discount

                // Calculate total (add shipping, taxes, etc., if applicable)
                double total = subtotal - discount; // Subtract discount from subtotal to get total
                lblTotal.Text = total.ToString(); // Display total

               string productNames = string.Join(", ", cartItems.AsEnumerable().Select(row => row.Field<string>("ProductName")));

                lblProductName.Text = productNames; // Display concatenated product names
            }
            else
            {
            // Handle empty cart
            // You might want to display a message or redirect to a different page
                lblProductName.Text = "";
                lblSubtotal.Text = "0.00"; // Display 0 as subtotal when cart is empty
                lbldiscount.Text = "0.00"; // Display 0 as discount when cart is empty
                lblTotal.Text = "0.00"; // Display 0 as total when cart is empty
                lblQuantity.Text = ""; // Display 0 as quantity when cart is empty
            }
    }

        private double CalculateDiscount(double subtotal)
        {
            if (subtotal > 100)
            {
                return subtotal * 0.03; // 10% discount
            }
            else
            {
                return 0; // No discount
            }

        }
    private int CalculateQuantity(DataTable cartItems)
    {
        int quantity = 0;
        foreach (DataRow row in cartItems.Rows)
        {
            int itemQuantity = Convert.ToInt32(row["Quantity"]);
            quantity += itemQuantity;
        }
        return quantity;
    }

    private double CalculateSubtotal(DataTable cartItems)
        {
            double subtotal = 0;
            foreach (DataRow row in cartItems.Rows)
            {
                subtotal += Convert.ToDouble(row["TotalPrice"]);
            }
            return subtotal;
        }

    int id;
    protected void btnPlaceOrder_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("INSERT INTO CheckoutTable(First_Name,Last_Name,Company_Name,Address,Apartment,State,Postal,Email_Address,Phone,Order_Notes,productName,Quantity,OfferPrice,Discount,Total) VALUES (@First_Name,@Last_Name,@Company_Name,@Address,@Apartment,@State,@Postal,@Email_Address,@Phone,@Order_Notes,@productName,@Quantity,@OfferPrice,@Discount,@Total)", con);
            cmd.Parameters.Add("@First_Name", SqlDbType.VarChar).Value = c_fname.Text;
            cmd.Parameters.Add("@Last_Name", SqlDbType.VarChar).Value = c_lname.Text;
            cmd.Parameters.Add("@Company_Name", SqlDbType.VarChar).Value = c_companyname.Text;
            cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = c_address.Text;
            cmd.Parameters.Add("@Apartment", SqlDbType.VarChar).Value = apartment.Text;
            cmd.Parameters.Add("@State", SqlDbType.VarChar).Value = c_state_country.Text;
            cmd.Parameters.Add("@Postal", SqlDbType.VarChar).Value = c_postal_zip.Text;
            cmd.Parameters.Add("@Email_Address", SqlDbType.VarChar).Value = c_email_address.Text;
            cmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = c_phone.Text;
            cmd.Parameters.Add("@Order_Notes", SqlDbType.VarChar).Value = c_order_notes.Text;
            cmd.Parameters.Add("@productName", SqlDbType.VarChar).Value = lblProductName.Text;
            cmd.Parameters.Add("@Quantity", SqlDbType.Int).Value = Convert.ToInt32(lblQuantity.Text);
            cmd.Parameters.Add("@OfferPrice", SqlDbType.Decimal).Value = Convert.ToDecimal(lblSubtotal.Text);
            cmd.Parameters.Add("@Discount", SqlDbType.Decimal).Value = Convert.ToDecimal(lbldiscount.Text);
            cmd.Parameters.Add("@Total", SqlDbType.Decimal).Value = Convert.ToDecimal(lblTotal.Text);
            cmd.ExecuteNonQuery();

            MessageBox("DATA SAVED");
        }
        catch (Exception )
        {
            // Handle exceptions
        }
        finally
        {
            con.Close();
        }

    }


    protected void ddlPaymentMethod_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }

    protected void btnPrintBill_Click(object sender, EventArgs e)
    {
        // Generate PDF bill
        GeneratePDFBill();
    }


    //private void GeneratePDFBill()
    //{
    //    using (MemoryStream memoryStream = new MemoryStream())
    //    {
    //        try
    //        {
    //            // Create a new PDF document
    //            Document doc = new Document();
    //            PdfWriter writer = PdfWriter.GetInstance(doc, memoryStream);

    //            // Open the document for writing
    //            doc.Open();

    //            // Add content to the document
    //            PdfPTable table = new PdfPTable(2); // 2 columns
    //            //table.AddCell("First_Name");
    //            //table.AddCell("Last_Name");
    //            //table.AddCell("Company_Name");
    //            //table.AddCell("Address");
    //            //table.AddCell("Apartment");
    //            //table.AddCell("State");
    //            //table.AddCell("Postal");
    //            //table.AddCell("Email_Address");
    //            //table.AddCell("Phone");
    //            //table.AddCell("Order_Notes");
    //            //table.AddCell("productName");
    //            //table.AddCell("OfferPrice");
    //            //table.AddCell("Discount");
    //            //table.AddCell("Total");

    //            // Fetch data from database
    //            string connectionString = "Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True";
    //            string query = "SELECT First_Name,Last_Name, Company_Name,Address,Apartment,State,Postal,Email_Address,Phone,Order_Notes,productName,OfferPrice,Discount,Total,Quantity FROM CheckoutTable where Id=id";

    //            using (SqlConnection connection = new SqlConnection(connectionString))
    //            {
    //                SqlCommand command = new SqlCommand(query, connection);
    //                connection.Open();
    //                SqlDataReader reader = command.ExecuteReader();

    //                while (reader.Read())
    //                {
    //                    // Add data to PDF table                       
    //                    table.AddCell(reader["First_Name"].ToString());
    //                    table.AddCell(reader["Last_Name"].ToString());
    //                    table.AddCell(reader["Company_Name"].ToString());
    //                    table.AddCell(reader["Address"].ToString());
    //                    table.AddCell(reader["Apartment"].ToString());
    //                    table.AddCell(reader["State"].ToString());
    //                    table.AddCell(reader["Postal"].ToString());
    //                    table.AddCell(reader["Email_Address"].ToString());
    //                    table.AddCell(reader["Phone"].ToString());
    //                    table.AddCell(reader["Order_Notes"].ToString());
    //                    table.AddCell(reader["productName"].ToString());
    //                    table.AddCell(reader["OfferPrice"].ToString());
    //                    table.AddCell(reader["Discount"].ToString());
    //                    table.AddCell(reader["Total"].ToString());
    //                    table.AddCell(reader["Quantity"].ToString());
    //                }
    //            }

    //            // Add the table to the document
    //            doc.Add(table);

    //            // Close the document
    //            doc.Close();

    //            // Clear the response content and set content type and headers
    //            Response.Clear();
    //            Response.ContentType = "application/pdf";
    //            Response.AddHeader("Content-Disposition", "attachment; filename=Bill.pdf");
    //            Response.Cache.SetCacheability(HttpCacheability.NoCache);

    //            // Write the PDF content to the response stream
    //            Response.BinaryWrite(memoryStream.ToArray());
    //        }
    //        catch (Exception ex)
    //        {
    //            // Handle exceptions appropriately
    //            Response.Write("An error occurred: " + ex.Message);
    //        }
    //        finally
    //        {
    //            // Dispose memory stream and end response
    //            memoryStream.Dispose();
    //            Response.End();
    //        }
    //    }
    //}
    
    private void GeneratePDFBill()
    {
        using (MemoryStream memoryStream = new MemoryStream())
        {
            try
            {
                // Create a new PDF document
                Document doc = new Document();
                PdfWriter writer = PdfWriter.GetInstance(doc, memoryStream);

                // Open the document for writing
                doc.Open();

                // Add content to the document
                PdfPTable table = new PdfPTable(15); // 15 columns
                //string id = "Id"; // Provide the actual ID here

                // Fetch data from database
                string connectionString = "Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True";
                string query = "SELECT First_Name, Last_Name, Company_Name, Address, Apartment, State, Postal, Email_Address, Phone, Order_Notes, productName, OfferPrice, Discount, Total, Quantity FROM CheckoutTable WHERE Id = id"; // Use parameterized query to prevent SQL injection

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        // Add header row
                        table.AddCell("First Name");
                        table.AddCell("Last Name");
                        table.AddCell("Company Name");
                        table.AddCell("Address");
                        table.AddCell("Apartment");
                        table.AddCell("State");
                        table.AddCell("Postal");
                        table.AddCell("Email Address");
                        table.AddCell("Phone");
                        table.AddCell("Order Notes");
                        table.AddCell("Product Name");
                        table.AddCell("Offer Price");
                        table.AddCell("Discount");
                        table.AddCell("Total");
                        table.AddCell("Quantity");

                        while (reader.Read())
                        {
                            // Add data to PDF table                       
                            table.AddCell(reader["First_Name"].ToString());
                            table.AddCell(reader["Last_Name"].ToString());
                            table.AddCell(reader["Company_Name"].ToString());
                            table.AddCell(reader["Address"].ToString());
                            table.AddCell(reader["Apartment"].ToString());
                            table.AddCell(reader["State"].ToString());
                            table.AddCell(reader["Postal"].ToString());
                            table.AddCell(reader["Email_Address"].ToString());
                            table.AddCell(reader["Phone"].ToString());
                            table.AddCell(reader["Order_Notes"].ToString());
                            table.AddCell(reader["productName"].ToString());
                            table.AddCell(reader["OfferPrice"].ToString());
                            table.AddCell(reader["Discount"].ToString());
                            table.AddCell(reader["Total"].ToString());
                            table.AddCell(reader["Quantity"].ToString());
                        }
                    }
                    else
                    {
                        // No rows found with the given ID
                        // You might want to handle this case accordingly
                        Response.Write("No data found for the provided ID.");
                        return;
                    }
                }

                // Add the table to the document
                doc.Add(table);

                // Close the document
                doc.Close();

                // Clear the response content and set content type and headers
                Response.Clear();
                Response.ContentType = "application/pdf";
                Response.AddHeader("Content-Disposition", "attachment; filename=Bill.pdf");
                Response.Cache.SetCacheability(HttpCacheability.NoCache);

                // Write the PDF content to the response stream
                Response.BinaryWrite(memoryStream.ToArray());
            }
            catch (Exception ex)
            {
                // Handle exceptions appropriately
                Response.Write("An error occurred: " + ex.Message);
            }
            finally
            {
                // Dispose memory stream and end response
                memoryStream.Dispose();
                Response.End();
            }
        }
    }


}