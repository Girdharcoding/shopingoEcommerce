﻿using System;
using System.Activities.Statements;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewFolder1_contact : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    private void MessageBox(string msg)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + msg + "'); window.location.reload();", true);
    }




    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO Contacttable(First_Name,Last_Name,Email,Subject,Message)VALUES(@First_Name,@Last_Name,@Email,@Subject,@Message)", con);
            cmd.Parameters.AddWithValue("First_Name",TextBox1.Text);
            cmd.Parameters.AddWithValue("Last_Name", TextBox2.Text);
            cmd.Parameters.AddWithValue("Email", TextBox3.Text);
            cmd.Parameters.AddWithValue("Subject", TextBox4.Text);
            cmd.Parameters.AddWithValue("Message", TextBox5.Text);
            con.Open();
            int res=cmd.ExecuteNonQuery();

            if (res == 0)
            {
                MessageBox("DATA Saved");
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message);

        }

    }
}