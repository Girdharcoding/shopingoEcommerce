﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewFolder1_Singleproduct : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getProductDetails();
        }
    }

    private void MessageBox(string msg)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + msg + "')", true);
    }
    int id;

    private void getProductDetails()
    {
        try
        {
            // Use using statement to ensure the connection is closed and disposed properly
            using (SqlConnection con = new SqlConnection())
            {
                // Use parameterized query to prevent SQL injection attacks
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM ProductTable WHERE Id = @Id", con))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Assuming 'Image' is the ID of the image control
                            Image.Attributes["src"] = "/UploadImage/" + reader["ImageName"].ToString();
                            lblProductName.Text = reader["ProductName"].ToString();
                            lblDescription.Text = reader["Description"].ToString();
                            lblPrice.Text = reader["Price"].ToString();
                            lblOfferPrice.Text = reader["OfferPrice"].ToString();
                            lblQuantity.Text = reader["Quantity"].ToString();
                        }
                        else
                        {
                            MessageBox("No product found with the specified ID.");
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message);
        }

    }
}