﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewFolder1_MasterPage : System.Web.UI.MasterPage
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindCategories();
            try
            {
                if (Session["cartitem"] != null)
                {
                    DataTable dt = (DataTable)Session["cartitem"];
                    if (dt.Rows.Count > 0)
                    {
                        lblCartCount.Text = dt.Rows.Count.ToString();
                    }
                    else
                    {
                        lblCartCount.Text = 0.ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox("Error" + ex.Message);
            }

        }

    }

    private void MessageBox(string msg)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "Showalert", "alert('" + msg + "')", true);
    }

    private void BindCategories()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM CategoriesTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                Repeater1.DataSource = dt;
                Repeater1.DataBind();
            }
            else
            {
                Repeater1.DataSource = null;
                Repeater1.DataBind();
            }
        }
        catch (Exception ex)
        {
            MessageBox(ex.Message);
        }
    }

    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            Repeater subrepeater = (Repeater)e.Item.FindControl("Repeater2");
            Label lblCategoryName = (Label)e.Item.FindControl("lblCategoryName");

            SqlCommand cmd = new SqlCommand("SELECT * FROM SubCategoriesTable WHERE Categories=@Categories", con);
            cmd.Parameters.AddWithValue("@Categories", lblCategoryName.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                subrepeater.DataSource = dt;
                subrepeater.DataBind();
            }
            else
            {
                subrepeater.DataSource = null;
                subrepeater.DataBind();
            }

        }

    }
}    