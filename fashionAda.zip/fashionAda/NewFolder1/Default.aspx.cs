﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewFolder1_Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-7PF94R28;Initial Catalog=Fashion;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            show();
        }

    }
    private void messagebox(string sms)
    {
        if (!string.IsNullOrEmpty(sms))
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + sms + "')", true);
        }
    }
    public void show()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM TableCarousel", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Repeater1.DataSource = dt;
                Repeater1.DataBind();
            }
            else
            {
                Repeater1.DataSource = null;
                Repeater1.DataBind();
            }

        }
        catch (Exception ex)
        {
            messagebox("failed" + ex.Message);
        }

    }
}